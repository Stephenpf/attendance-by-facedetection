### An automated attendance system based on face recognition 
